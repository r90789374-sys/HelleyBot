Funny Profile Dashboard - Netlify package

1) Upload this ZIP to Netlify using "Add new site" / "Deploy manually" or the "Drop files to deploy" area.
2) The ZIP contains index.html at its root.
3) Supabase project URL and publishable key are already configured in index.html. The publishable key is intended for browser use; never put a Supabase secret/service_role key in this site.
4) The first time you enter an access code in the Search field and press Enter, the page asks you to set the trigger code in this browser. Enter your existing old code there, then enter it again in Search when needed. This is only a hidden-panel convenience, NOT authentication. Real admin protection is Supabase Auth + your existing RLS policies.
5) Sign in with the Supabase Auth admin email/password you created. Do not share your password.
6) Existing Google Sheets / Drive data is NOT automatically migrated. Export/import profiles, media and Account text separately before relying on the new site.
7) Keep the old Apps Script dashboard active until the Netlify site has been tested.

Important:
- Public media uploads are enabled by your Storage policies. Because anonymous uploads can be abused, monitor the bucket and database.
- Profile image uploads require Admin login; public media submissions are open according to the current RLS policy.
- Netlify is static hosting; the app connects directly to Supabase.


Admin trigger fix: type the trigger code in the dashboard search and press Search/Enter. On first use, confirm storing it in this browser. Actual admin actions remain protected by Supabase Auth and RLS.
